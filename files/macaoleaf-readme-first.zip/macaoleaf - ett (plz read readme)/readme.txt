This is a layout modified directly from bai-xi.

To use the noteskin, move bai-xi folder to Etterna/NoteSkins/dance;

To use my layout as shown in videos, first find your own playerConfig.lua in Etterna/Save/LocalProfiles/00000000(or your specified name if there is any)/Til Death_settings(or your theme name).
Open the file using text editor; replace 4-key configs with my configs including size information and position information.
You may save your own file as a copy just in case.

- macaoleaf