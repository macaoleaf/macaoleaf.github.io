return LoadActor("_bar hold explosion bright")..{
	CheckpointHitCommand=cmd(diffusealpha,0);
};