This is a layout modified directly from bai-xi.

To use the noteskin, move bai-xi folder to Etterna/NoteSkins/dance;

To use my layout as shown in videos, move playerConfig file to Etterna/Save/LocalProfiles/00000000(or your specified name if there is any)/Til Death_settings(or your theme name).
Replace your original file if there is one. You can move it to somewhere else just in case.