return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_bar', 'mine' );
	Frame0000=0;
	Delay0000=1;
	Frame0001=1;
	Delay0001=1;
	Frame0002=2;
	Delay0002=1;
	Frame0003=3;
	Delay0003=1;
	Frame0004=2;
	Delay0004=1;
	Frame0005=1;
	Delay0005=1;
};